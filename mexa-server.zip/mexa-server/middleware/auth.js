// Ce middleware s'assure que la personne qui appelle l'API est bien
// connectée (elle a un "ticket" JWT valide). Il est utilisé devant
// PRESQUE toutes les routes, sauf /api/auth/login.
const jwt = require("jsonwebtoken");

function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: "Non connecté. Veuillez vous reconnecter." });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    // On attache l'utilisateur décodé à la requête pour que les routes
    // suivantes sachent QUI fait la demande et POUR QUELLE ENTREPRISE.
    req.user = payload; // { userId, businessId, role, username }
    next();
  } catch (err) {
    return res.status(401).json({ error: "Session expirée ou invalide. Veuillez vous reconnecter." });
  }
}

// À utiliser après requireAuth pour bloquer une route aux non-admins.
// Exemple : router.delete('/:id', requireAuth, requireAdmin, handler)
function requireAdmin(req, res, next) {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Action réservée à un administrateur." });
  }
  next();
}

module.exports = { requireAuth, requireAdmin };
